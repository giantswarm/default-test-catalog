{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "aws-ebs-csi-driver.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "aws-ebs-csi-driver.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "aws-ebs-csi-driver.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Determine image
*/}}
{{- define "aws-ebs-csi-driver.fullImagePath" -}}
{{ printf "%s%s:%s" (default "" .Values.image.containerRegistry) .Values.image.repository (default (printf "v%s" .Chart.AppVersion) (.Values.image.tag | toString)) }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "aws-ebs-csi-driver.labels" -}}
{{ include "aws-ebs-csi-driver.selectorLabels" . }}
{{- if ne .Release.Name "kustomize" }}
helm.sh/chart: {{ include "aws-ebs-csi-driver.chart" . | quote }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/component: csi-driver
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
{{- end }}
{{- if .Values.customLabels }}
{{ toYaml .Values.customLabels }}
{{- end }}
{{- end -}}

{{/*
Common selector labels
*/}}
{{- define "aws-ebs-csi-driver.selectorLabels" -}}
app.kubernetes.io/name: {{ include "aws-ebs-csi-driver.name" . | quote }}
{{- if ne .Release.Name "kustomize" }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end }}
{{- end -}}

{{/*
Convert the `--extra-tags` command line arg from a map.
*/}}
{{- define "aws-ebs-csi-driver.extra-volume-tags" -}}
{{- $result := dict "pairs" (list) -}}
{{- range $key, $value := .Values.controller.extraVolumeTags -}}
{{- $noop := printf "%s=%v" $key $value | append $result.pairs | set $result "pairs" -}}
{{- end -}}
{{- if gt (len $result.pairs) 0 -}}
- {{ printf "--extra-tags=%s" (join "," $result.pairs) | quote }}
{{- end -}}
{{- end -}}

{{/*
Handle http proxy env vars
*/}}
{{- define "aws-ebs-csi-driver.http-proxy" -}}
- name: HTTP_PROXY
  value: {{ .Values.proxy.http_proxy | quote }}
- name: HTTPS_PROXY
  value: {{ .Values.proxy.http_proxy | quote }}
- name: NO_PROXY
  value: {{ .Values.proxy.no_proxy | quote }}
{{- end -}}

{{/*
Recommended daemonset tolerations
*/}}
{{- define "aws-ebs-csi-driver.daemonset-tolerations" -}}
# Prevents stateful workloads from being scheduled to node before CSI Driver reports volume attachment limit
- key: "ebs.csi.aws.com/agent-not-ready"
  operator: "Exists"
# Prevents undesired eviction by Cluster Autoscalar
- key: "ToBeDeletedByClusterAutoscaler"
  operator: Exists
# Prevents undesired eviction by v1 Karpenter
- key: "karpenter.sh/disrupted"
  operator: Exists
# Prevents undesired eviction by v1beta1 Karpenter
- key: "karpenter.sh/disruption"
  operator: Exists
{{- end -}}

{{/*
Render an IntOrString value safely. A string that is a plain integer is emitted
as a bare integer (so an int stays an int for the API server); anything else is
emitted via toYaml, which quotes/escapes it and prevents YAML injection from a
value that contains newlines or document separators.
*/}}
{{- define "aws-ebs-csi-driver.int-or-string" -}}
{{- if not (kindIs "invalid" .) -}}
{{- $parsed := 0 -}}
{{- $isInteger := false -}}
{{- if kindIs "string" . -}}
{{- $parsed = atoi . -}}
{{- $isInteger = eq (toString $parsed) . -}}
{{- end -}}
{{- if $isInteger -}}
{{ $parsed }}
{{- else -}}
{{ . | toJson }}
{{- end -}}
{{- end -}}
{{- end -}}
