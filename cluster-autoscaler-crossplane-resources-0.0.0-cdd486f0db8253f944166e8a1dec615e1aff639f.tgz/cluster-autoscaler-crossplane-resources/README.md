# cluster-autoscaler-crossplane-resources

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square)

Crossplane Resources for Cluster Autoscaler

**Homepage:** <https://github.com/giantswarm/cluster-autoscaler-crossplane-resources>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aws | object | See below. | AWS settings. |
| aws.account | object | See below. | AWS account settings. |
| aws.account.id | string | `""` | AWS account ID. |
| aws.enabled | bool | `false` | If AWS is enabled. |
| aws.oidc | object | See below. | AWS OIDC settings. |
| aws.oidc.domains | list | `[]` | AWS OIDC domains. |
| aws.partition | string | `""` | AWS partition. |
| clusterID | string | `""` | Cluster ID. |
| serviceAccount | object | See below. | Service account settings. |
| serviceAccount.name | string | `"cluster-autoscaler"` | Service account name. |
| serviceAccount.namespace | string | `"kube-system"` | Service account namespace. |
