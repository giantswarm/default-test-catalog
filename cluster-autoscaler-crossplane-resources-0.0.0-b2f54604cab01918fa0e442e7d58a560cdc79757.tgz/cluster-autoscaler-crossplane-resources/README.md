# cluster-autoscaler-crossplane-resources

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square)

Crossplane Resources for Cluster Autoscaler

**Homepage:** <https://github.com/giantswarm/cluster-autoscaler-crossplane-resources>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aws | object | `{"accountID":"","oidcDomains":[],"partition":""}` | AWS settings. |
| aws.accountID | string | `""` | AWS account ID. |
| aws.oidcDomains | list | `[]` | AWS OIDC domains. |
| aws.partition | string | `""` | AWS partition. |
| clusterID | string | `""` | Cluster ID. |
| provider | string | `""` | Provider. |
| serviceAccount | object | `{"name":"cluster-autoscaler","namespace":"kube-system"}` | Service account settings. |
| serviceAccount.name | string | `"cluster-autoscaler"` | Service account name. |
| serviceAccount.namespace | string | `"kube-system"` | Service account namespace. |
