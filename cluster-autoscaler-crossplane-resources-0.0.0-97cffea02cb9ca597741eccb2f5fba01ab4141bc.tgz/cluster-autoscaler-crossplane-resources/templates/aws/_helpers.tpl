{{/*
Lookup Crossplane config values.
*/}}
{{- define "cluster-autoscaler-crossplane-resources.aws.crossplane-config-values" -}}
{{- $configMapName := printf "%s-crossplane-config" .Values.cluster.name }}
{{- $configMap := lookup "v1" "ConfigMap" .Release.Namespace $configMapName }}
{{- $configMap.data.values }}
{{- end }}
